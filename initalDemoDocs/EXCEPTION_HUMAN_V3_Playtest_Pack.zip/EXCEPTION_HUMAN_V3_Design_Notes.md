# EXCEPTION: HUMAN — Misclassification Update (V3)

## Design goal
Keep V2's responsive 2D platforming and frequent failure, but replace familiar spike/falling-block/standard platform visuals with hazards caused by an AI making false assertions about the world. The player is an *out-of-distribution human*; the environment is a document edited by a self-assured machine.

## New identity
- **World as a misclassified document:** warm grid paper, document margins, `reality.json`, typed object labels and disappearing annotations. The world is not a conventional fantasy or pixel-art platformer.
- **The observer:** a large procedural machine-vision eye tracks the player. Its identification panel confidently calls the human "unsupported" and the world "totally safe." It changes to an alarm state during forecasts.
- **The human as the edge case:** a hand-drawn figure framed by computer-vision brackets rather than a standard adventurer sprite.
- **All art is generated using Canvas 2D:** no borrowed sprites, asset packs, external fonts, images, downloads, model/API dependencies, or network requests.

## Replaced hazards
| V2 | V3 | Physical gameplay behavior |
|---|---|---|
| Spikes | **False-positive classifier** | A scanning detection bounding box activates ahead of the player's movement; entering its area while active is lethal. On a retry, its known location can be read in advance. No triangular spikes are drawn. |
| Collapsing floor | **Redaction** | AI removes strips of the world like deleted text, changing the traversable floor. The loss has a warning phase and persistent learned marker on future attempts. |
| Falling blocks | **Policy popup** | A heavyweight interface modal interrupts physical space and crushes anyone standing in its impact zone. The popup has a visible callout and a clear drop/hold/withdrawal phase. |
| Standard pits | **NULL reference** | A visibly unresolved region of `reality.json` is dangerous until the player convinces the model that `NULL` is a valid bridge. |
| Wall | **Misclassified object** | Wall behavior can be temporarily rewritten into passable `AIR` using X. Reappearing geometry can kill the player if they linger. |
| Fake exit | **Recommended / JPG exit** | The AI mistakes an exit recommendation or image for the real thing, forcing the player to reclassify it just before escaping. |
| No equivalent | **Predictive purge** | NEW mechanical threat. The AI predicts the future x-position based on the player's movement direction, locks a ghost silhouette as its forecast, and later erases that region. The player can *bait* the forecast and move somewhere else. |

## Why the resulting game is less derivative
The game's obstacles have a common semantic origin: a classifier's confidence changes the rules of matter. Hazards are diegetic error handling, not an assortment of conventional platforms with spikes and saws. The **predictive purge** is also a genuine new action/reaction mechanic, not a visual reskin. It converts the player's momentum into a target, creating bait-and-dodge strategy.

This does **not** establish that the game is wholly unprecedented. Genre-standard movement, timed deaths, instant retries, and learning traps remain deliberately familiar. Further differentiation should build on player-authored reclassification chains, not add another catalog of standard traps.

## Rooms
1. **Content Not Found** — learn to jump a redaction and evade a false-positive classifier.
2. **The Implied Bridge** — rewrite NULL into a temporary crossing; avoid a redaction and misleading suggested exit.
3. **Predictive Policing** — clear a missing reference, wait out/avoid a physical notification, rewrite a barrier, then bait the predictive purge.
4. **Terms Have Changed** — classifier, redaction, popup, and temporary NULL bridge combine in a compact sequence.
5. **Exit Classification Error** — redaction, wall rewrite, predictive purge, classifier, and the JPG-exit audit.

## Build, controls, and scope
- One offline, self-contained HTML file. Open directly in a browser.
- **A/D** move, **Space/W** jump, **X** rewrite nearest classifiable object, **R** restart, touch buttons included.
- No actual generative AI runs during play. Behavior and AI dialogue are deterministic and tuned for fair practice. A real LLM should only ever be an optional, non-authoritative narrator, not collision or trap logic.

## Quality checks completed
- Verified valid JavaScript syntax and loaded the browser document without a page script error.
- Ran a scripted input route that completed all five rooms.
- Browser-tested that a false-positive scan area activates and causes a death.
- Browser-tested that predictive purge obtains a specific target x and enters the telegraph phase before firing.
- Captured overview and forecast screenshots.

## Playtesting still needed
Scripted completion verifies the rooms are mechanically traversable, **not** that people find them fair, hard, funny, original, or addictive. Observe first-try deaths, surprise-to-retreat rate, player comprehension of what `X` can do, repeat attempts after death, and whether the novel predictor is more entertaining than the standard redaction/scanner hazards.

## Candidates for V4 (avoid scope creep)
- Turn an enemy's false-positive box into an *approved safe path* by rewriting its classification, with a short expiration.
- AI autocomplete: an object physically moves to the wrong noun's location; players can choose which mistake to trigger.
- Asynchronous ghost overlays of other players tricking the classifier, with no networked co-op physics required.
